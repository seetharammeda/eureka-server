/**
 * @license Angular v8.1.0
 * (c) 2010-2019 Google LLC. https://angular.io/
 * License: MIT
 */

export * from './http/http';
