export declare function findTests(patterns: string[], cwd: string, workspaceRoot: string): string[];
