import * as webpack from 'webpack';
import { WebpackConfigOptions } from '../build-options';
export declare function getBrowserConfig(wco: WebpackConfigOptions): webpack.Configuration;
